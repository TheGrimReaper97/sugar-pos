// src/components/Dashboard.js
import React from 'react';
import './Dashboard.css';

const Dashboard = ({ onLogout }) => {
  return (
    <div className="dashboard-container">
      <h1>Welcome to the Dashboard!</h1>
      <button onClick={onLogout}>Logout</button>
    </div>
  );
};

export default Dashboard;
